package savetheworld;

import javax.swing.JFrame;

import savetheworld.Modelo.Fase;

public class SaveTheWorld extends JFrame {

	public SaveTheWorld(int i) {
		add(new Fase(i));
		setTitle("T� Chovendo Lixo");
		setSize(960, 540);
		setLocationRelativeTo(null);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		this.setResizable(false);
		setVisible(true);
	}

	public static void main(String[] args) {
		new SaveTheWorld(0);
	}
}