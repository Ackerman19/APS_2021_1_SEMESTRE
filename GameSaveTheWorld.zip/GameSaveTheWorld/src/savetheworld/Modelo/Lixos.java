package savetheworld.Modelo;

import java.applet.Applet;
import java.applet.AudioClip;
import java.awt.Image;
import java.awt.Rectangle;
import java.net.URL;

import javax.swing.ImageIcon;

public class Lixos {
	private Image imagem;
	private int x, y, largura, altura;
	private int cont;
	private int reiM;
	private boolean isVisible;
	private Som som;

	public Lixos(int x, int y, int cont) {
		this.x = x;
		this.y = y;
		this.cont = cont;
		isVisible = true;
		som = new Som();
	}

	public void load() {
		if (cont % 2 == 0 && cont < 7) {
			ImageIcon lixo = new ImageIcon("image\\papel.png");
			imagem = lixo.getImage();
		} else if (cont == 1) {
			ImageIcon lixo = new ImageIcon("image\\papel.png");
			imagem = lixo.getImage();
		} else if (cont == 3) {
			ImageIcon lixo = new ImageIcon("image\\metal.png");
			imagem = lixo.getImage();
		} else if (cont == 5) {
			ImageIcon lixo = new ImageIcon("image\\vidro.png");
			imagem = lixo.getImage();
		} else if (cont == 7) {
			ImageIcon lixo = new ImageIcon("image\\plastico.png");
			imagem = lixo.getImage();
		}

		this.altura = imagem.getHeight(null);
		this.largura = imagem.getWidth(null);
	}

	public void update() {
		this.y += 3;
		if (this.y > 450) {
			isVisible = false;
			Fase.reiM++;
		}
	}

	public Rectangle getInfos() {
		return new Rectangle(x, y, largura, altura);
	}

	public Image getImagem() {
		return imagem;
	}

	public boolean isVisible() {
		return isVisible;
	}

	public void setVisible(boolean isVisible) {
		this.isVisible = isVisible;
	}

	public int getX() {
		return x;
	}

	public int getY() {
		return y;
	}

}