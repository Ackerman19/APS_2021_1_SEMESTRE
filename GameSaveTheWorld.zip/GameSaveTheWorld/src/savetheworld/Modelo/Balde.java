package savetheworld.Modelo;

import java.awt.Image;
import java.awt.Rectangle;
import java.awt.event.KeyEvent;

import javax.swing.ImageIcon;

import savetheworld.SaveTheWorld;

public class Balde {
	private int x, y, largura, altura;
	private int dx;
	private String background;
	private Image background2;
	private String imagem;
	private Image imagem2;
	private boolean isVisible;

	public Balde(String imagem, String background) {
		this.background = background;
		this.imagem = imagem;
		this.x = 400;
		this.y = 410;
		isVisible = true;
	}

	public void load() {
		ImageIcon lixo = new ImageIcon(imagem);
		getImagem();
		imagem2 = lixo.getImage();

		ImageIcon fundo = new ImageIcon(background);
		background2 = fundo.getImage();
		this.altura = imagem2.getHeight(null);
		this.largura = imagem2.getWidth(null);
	}

	public void update() {
		x += dx;
	}

	public Rectangle getInfos() {
		return new Rectangle(x, y, largura, altura);
	}

	public void keyPressed(KeyEvent tecla) {
		int codigo = tecla.getKeyCode();

		if (x <= 0) {
			if (codigo == KeyEvent.VK_A || codigo == KeyEvent.VK_LEFT) {
				dx = 0;
			}
			if (codigo == KeyEvent.VK_D || codigo == KeyEvent.VK_RIGHT) {
				dx = 5;
			}
		} else if (x >= 870) {
			if (codigo == KeyEvent.VK_A || codigo == KeyEvent.VK_LEFT) {
				dx = -5;
			}
			if (codigo == KeyEvent.VK_D || codigo == KeyEvent.VK_RIGHT) {
				dx = 0;
			}
		} else {
			if (codigo == KeyEvent.VK_A || codigo == KeyEvent.VK_LEFT) {
				dx = -5;
			}

			if (codigo == KeyEvent.VK_D || codigo == KeyEvent.VK_RIGHT) {
				dx = 5;
			}
		}
	}

	public void keyRelease(KeyEvent tecla) {
		int codigo = tecla.getKeyCode();

		if (codigo == KeyEvent.VK_A || codigo == KeyEvent.VK_D || codigo == KeyEvent.VK_LEFT
				|| codigo == KeyEvent.VK_RIGHT) {
			dx = 0;
		}

	}

	public boolean getVisible() {
		return isVisible;
	}

	public void setVisible(boolean isVisible) {
		this.isVisible = isVisible;
	}

	public int getX() {
		return x;
	}

	public int getY() {
		return y;
	}

	public Image getImagem() {
		return imagem2;
	}

	public Image getImagemB() {
		return background2;
	}
}