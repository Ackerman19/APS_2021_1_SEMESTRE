package savetheworld.Modelo;

import java.applet.Applet;
import java.applet.AudioClip;
import java.awt.Component;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.Rectangle;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;

import javax.swing.ImageIcon;
import javax.swing.JPanel;
import javax.swing.Timer;

public class Fase extends JPanel implements ActionListener {
	private Image background;
	private Timer timer;
	private Balde lixeira[];
	private List<Lixos> lixos;
	public int cont = 0;
	private int pontos = 0;
	private Pontuacao pontuacao[];
	private Lixos a;
	private int numerador = 0;
	static int reiM = 0;
	private Som som;

	public Fase(int i) {
		lixeira = new Balde[9];
		lixeira[0] = new Balde(null, "image\\fase1.jpg");
		lixeira[1] = new Balde("image\\LixeiraAzul.png", "image\\backgroundDia.jpg");
		lixeira[2] = new Balde(null, "image\\fase2.jpg");
		lixeira[3] = new Balde("image\\LixeiraAmarela.png", "image\\backgroundDia.jpg");
		lixeira[4] = new Balde(null, "image\\fase3.jpg");
		lixeira[5] = new Balde("image\\LixeiraVerde.png", "image\\backgroundNoite.jpg");
		lixeira[6] = new Balde(null, "image\\fase4.jpg");
		lixeira[7] = new Balde("image\\LixeiraVermelha.png", "image\\backgroundNoite.jpg");
		lixeira[8] = new Balde(null, "image\\backgroundFim2.jpg");

		pontuacao = new Pontuacao[26];
		pontuacao[0] = new Pontuacao("image\\0.png");
		pontuacao[1] = new Pontuacao("image\\10.png");
		pontuacao[2] = new Pontuacao("image\\20.png");
		pontuacao[3] = new Pontuacao("image\\30.png");
		pontuacao[4] = new Pontuacao("image\\40.png");
		pontuacao[5] = new Pontuacao("image\\50.png");
		pontuacao[6] = new Pontuacao("image\\60.png");
		pontuacao[7] = new Pontuacao("image\\70.png");
		pontuacao[8] = new Pontuacao("image\\80.png");
		pontuacao[9] = new Pontuacao("image\\90.png");
		pontuacao[10] = new Pontuacao("image\\100.png");
		pontuacao[11] = new Pontuacao("image\\110.png");
		pontuacao[12] = new Pontuacao("image\\120.png");
		pontuacao[13] = new Pontuacao("image\\130.png");
		pontuacao[14] = new Pontuacao("image\\140.png");
		pontuacao[15] = new Pontuacao("image\\150.png");
		pontuacao[16] = new Pontuacao("image\\160.png");
		pontuacao[17] = new Pontuacao("image\\170.png");
		pontuacao[18] = new Pontuacao("image\\180.png");
		pontuacao[19] = new Pontuacao("image\\190.png");
		pontuacao[20] = new Pontuacao("image\\200.png");
		pontuacao[21] = new Pontuacao("image\\210.png");
		pontuacao[22] = new Pontuacao("image\\220.png");
		pontuacao[23] = new Pontuacao("image\\230.png");
		pontuacao[24] = new Pontuacao("image\\240.png");
		pontuacao[25] = new Pontuacao("image\\250.png");

		lixeira[cont].load();
		pontuacao[pontos].load();

		addKeyListener(new TecladoAdapter());

		timer = new Timer(1, this);
		timer.start();

		dropLixo();

		setFocusable(true);
		setDoubleBuffered(true);

		som = new Som();
	}

	public void dropLixo() {

		lixos = new ArrayList<Lixos>();

		for (int i = 0; i < 10 + numerador; i++) {
			int y = (int) (Math.random() * -7000 + 30);
			int x = (int) (Math.random() * 900 + 0);
			lixos.add(new Lixos(x, y, cont));
		}

	}

	public void paint(Graphics g) {
		Graphics2D graficos = (Graphics2D) g;
		graficos.drawImage(lixeira[cont].getImagemB(), 0, 0, null);
		if (cont % 2 == 0) {

		} else {
			graficos.drawImage(lixeira[cont].getImagem(), lixeira[cont].getX(), lixeira[cont].getY(), this);
			graficos.drawImage(pontuacao[pontos].getImagem(), pontuacao[pontos].getX(), pontuacao[pontos].getY(), null);

			for (int b = 0; b < lixos.size(); b++) {
				this.a = lixos.get(b);
				this.a.load();
				graficos.drawImage(this.a.getImagem(), this.a.getX(), this.a.getY(), this);
			}
		}
		g.dispose();
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		lixeira[cont].update();
		repaint();

		for (int b = 0; b < lixos.size(); b++) {
			Lixos a = lixos.get(b);
			if (a.isVisible()) {
				a.update();
			} else {
				lixos.remove(b);
			}
		}
		pegaLixo();

	}

	public void pegaLixo() {
		Rectangle lixo;
		Rectangle lixeira = this.lixeira[cont].getInfos();
		;
		for (int i = 0; i < lixos.size(); i++) {
			Lixos colLixo = lixos.get(i);
			lixo = colLixo.getInfos();
			if (lixo.intersects(lixeira)) {
				colLixo.setVisible(false);
				pontos += 1;
				recarrega();
				reiM++;
				som.tocarSom("PLSTBANG.WAV");
			}

			if (pontos == 8 + numerador) {
				reinicia();
			}
			if (reiM == 10 + numerador) {
				if (pontos <= 7 + numerador) {
					som.tocarSom("PLOP.WAV");
					if (this.cont != 0) {
						reiniciaMorte();
					}
				}
			}
		}
	}

	public void reinicia() {
		if (cont % 2 != 0) {
			numerador += 5;
		}
		cont += 1;
		pontos = 0;
		reiM = 0;
		dropLixo();
		recarrega();
	}

	public void reiniciaMorte() {
		cont = 0;
		pontos = 0;
		numerador = 0;
		reiM = 0;
		dropLixo();
		recarrega();
	}

	public void recarrega() {
		lixeira[cont].load();
		pontuacao[pontos].load();
		cont--;
		if (cont % 2 != 0) {
			this.a.load();
		}
		cont++;
	}

	private class TecladoAdapter extends KeyAdapter {

		@Override
		public void keyPressed(KeyEvent e) {
			lixeira[cont].keyPressed(e);
			if (cont % 2 == 0 && cont < 7) {
				try {
					Thread.sleep(3000);
					som.tocarSom("VENTO.wav");
					reinicia();
				} catch (InterruptedException l) {
					l.printStackTrace();
				}
			} else if (cont == 8) {
				try {
					som.tocarSom("CLAPCLAP.wav");
					Thread.sleep(5300);
					reiniciaMorte();
				} catch (InterruptedException l) {
					l.printStackTrace();
				}
			}
		}

		@Override
		public void keyReleased(KeyEvent e) {
			lixeira[cont].keyRelease(e);
		}
	}
}