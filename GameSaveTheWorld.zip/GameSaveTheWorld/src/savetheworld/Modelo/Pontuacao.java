package savetheworld.Modelo;

import java.awt.Image;

import javax.swing.ImageIcon;

public class Pontuacao {

	private Image imagem;
	private String imagem2;
	private int x, y;

	public Pontuacao(String imagem2) {
		this.imagem2 = imagem2;
		this.x = 440;
		this.y = 10;
	}

	public void load() {
		ImageIcon pontos = new ImageIcon(imagem2);
		imagem = pontos.getImage();
	}

	public Image getImagem() {
		return imagem;
	}

	public int getX() {
		return x;
	}

	public int getY() {
		return y;
	}

}