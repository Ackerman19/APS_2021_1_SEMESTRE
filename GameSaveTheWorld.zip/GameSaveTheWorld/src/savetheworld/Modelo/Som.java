package savetheworld.Modelo;

import java.applet.Applet;
import java.applet.AudioClip;
import java.net.URL;

public class Som {

	public void tocarSom(String audio) {
		URL som = getClass().getResource(audio);
		AudioClip Som = Applet.newAudioClip(som);
		Som.play();
	}
}
